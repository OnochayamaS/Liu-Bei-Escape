<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="Overworld_Terrain" tilewidth="64" tileheight="64" tilecount="629" columns="17">
 <image source="../../graphics/tilesets/Overworld_tileset.png" width="1088" height="2400"/>
</tileset>
