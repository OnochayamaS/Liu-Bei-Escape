<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="Items" tilewidth="30" tileheight="32" tilecount="3" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image source="../../graphics/objects/items/rune.png" width="30" height="32"/>
 </tile>
 <tile id="1">
  <image source="../../graphics/objects/items/coin.png" width="18" height="20"/>
 </tile>
 <tile id="2">
  <image source="../../graphics/objects/items/key.png" width="24" height="16"/>
 </tile>
</tileset>
