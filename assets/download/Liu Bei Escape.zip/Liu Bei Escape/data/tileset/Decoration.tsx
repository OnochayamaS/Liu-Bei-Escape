<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="Decoration" tilewidth="398" tileheight="366" tilecount="50" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="47">
  <image source="../../graphics/objects/willows/2.png" width="398" height="366"/>
 </tile>
 <tile id="48">
  <image source="../../graphics/objects/willows/0.png" width="208" height="270"/>
 </tile>
 <tile id="49">
  <image source="../../graphics/objects/willows/1.png" width="282" height="336"/>
 </tile>
 <tile id="50">
  <image source="../../graphics/objects/box/5.png" width="27" height="26"/>
 </tile>
 <tile id="51">
  <image source="../../graphics/objects/box/0.png" width="34" height="28"/>
 </tile>
 <tile id="52">
  <image source="../../graphics/objects/box/1.png" width="34" height="27"/>
 </tile>
 <tile id="53">
  <image source="../../graphics/objects/box/2.png" width="27" height="26"/>
 </tile>
 <tile id="54">
  <image source="../../graphics/objects/box/3.png" width="33" height="26"/>
 </tile>
 <tile id="55">
  <image source="../../graphics/objects/box/4.png" width="34" height="27"/>
 </tile>
 <tile id="65">
  <image source="../../graphics/objects/bushes/0.png" width="62" height="30"/>
 </tile>
 <tile id="66">
  <image source="../../graphics/objects/bushes/1.png" width="60" height="20"/>
 </tile>
 <tile id="67">
  <image source="../../graphics/objects/bushes/2.png" width="58" height="30"/>
 </tile>
 <tile id="68">
  <image source="../../graphics/objects/bushes/3.png" width="62" height="42"/>
 </tile>
 <tile id="69">
  <image source="../../graphics/objects/bushes/4.png" width="126" height="56"/>
 </tile>
 <tile id="70">
  <image source="../../graphics/objects/bushes/5.png" width="62" height="52"/>
 </tile>
 <tile id="71">
  <image source="../../graphics/objects/bushes/6.png" width="122" height="48"/>
 </tile>
 <tile id="72">
  <image source="../../graphics/objects/bushes/7.png" width="126" height="54"/>
 </tile>
 <tile id="73">
  <image source="../../graphics/objects/bushes/8.png" width="122" height="50"/>
 </tile>
 <tile id="96">
  <image source="../../graphics/objects/pointer/0.png" width="32" height="42"/>
 </tile>
 <tile id="97">
  <image source="../../graphics/objects/pointer/1.png" width="32" height="42"/>
 </tile>
 <tile id="98">
  <image source="../../graphics/objects/pointer/2.png" width="26" height="42"/>
 </tile>
 <tile id="99">
  <image source="../../graphics/objects/pointer/3.png" width="26" height="42"/>
 </tile>
 <tile id="100">
  <image source="../../graphics/objects/pointer/4.png" width="26" height="42"/>
 </tile>
 <tile id="101">
  <image source="../../graphics/objects/pointer/5.png" width="26" height="42"/>
 </tile>
 <tile id="102">
  <image source="../../graphics/objects/pointer/6.png" width="26" height="42"/>
 </tile>
 <tile id="103">
  <image source="../../graphics/objects/pointer/7.png" width="22" height="42"/>
 </tile>
 <tile id="104">
  <image source="../../graphics/objects/ridges/0.png" width="178" height="52"/>
 </tile>
 <tile id="105">
  <image source="../../graphics/objects/ridges/1.png" width="80" height="56"/>
 </tile>
 <tile id="106">
  <image source="../../graphics/objects/ridges/2.png" width="218" height="82"/>
 </tile>
 <tile id="107">
  <image source="../../graphics/objects/ridges/3.png" width="130" height="122"/>
 </tile>
 <tile id="108">
  <image source="../../graphics/objects/ridges/4.png" width="162" height="58"/>
 </tile>
 <tile id="109">
  <image source="../../graphics/objects/ridges/5.png" width="94" height="110"/>
 </tile>
 <tile id="115">
  <image source="../../graphics/objects/stones/0.png" width="126" height="118"/>
 </tile>
 <tile id="116">
  <image source="../../graphics/objects/stones/1.png" width="94" height="114"/>
 </tile>
 <tile id="117">
  <image source="../../graphics/objects/stones/2.png" width="104" height="126"/>
 </tile>
 <tile id="118">
  <image source="../../graphics/objects/stones/3.png" width="114" height="60"/>
 </tile>
 <tile id="119">
  <image source="../../graphics/objects/stones/4.png" width="62" height="62"/>
 </tile>
 <tile id="123">
  <image source="../../graphics/objects/trees/0.png" width="202" height="206"/>
 </tile>
 <tile id="124">
  <image source="../../graphics/objects/trees/1.png" width="208" height="264"/>
 </tile>
 <tile id="125">
  <image source="../../graphics/objects/trees/2.png" width="246" height="300"/>
 </tile>
 <tile id="126">
  <image source="../../graphics/objects/grass/0.png" width="17" height="18"/>
 </tile>
 <tile id="127">
  <image source="../../graphics/objects/grass/5.png" width="11" height="9"/>
 </tile>
 <tile id="128">
  <image source="../../graphics/objects/grass/6.png" width="7" height="14"/>
 </tile>
 <tile id="129">
  <image source="../../graphics/objects/grass/7.png" width="8" height="14"/>
 </tile>
 <tile id="130">
  <image source="../../graphics/objects/grass/8.png" width="6" height="8"/>
 </tile>
 <tile id="131">
  <image source="../../graphics/objects/grass/9.png" width="9" height="11"/>
 </tile>
 <tile id="132">
  <image source="../../graphics/objects/grass/1.png" width="17" height="16"/>
 </tile>
 <tile id="133">
  <image source="../../graphics/objects/grass/2.png" width="14" height="16"/>
 </tile>
 <tile id="134">
  <image source="../../graphics/objects/grass/3.png" width="12" height="12"/>
 </tile>
 <tile id="135">
  <image source="../../graphics/objects/grass/4.png" width="11" height="13"/>
 </tile>
</tileset>
