<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="grass" tilewidth="17" tileheight="18" tilecount="1" columns="0">
 <grid orientation="orthogonal" width="32" height="32"/>
 <tile id="0">
  <image source="../../graphics/tilesets/1.png" width="17" height="18"/>
 </tile>
</tileset>
