<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="Objects" tilewidth="110" tileheight="96" tilecount="6" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image source="../../graphics/objects/player.png" width="110" height="96"/>
 </tile>
 <tile id="1">
  <image source="../../graphics/objects/flag.png" width="98" height="96"/>
 </tile>
 <tile id="2">
  <image source="../../graphics/objects/floor_spikes.png" width="64" height="64"/>
 </tile>
 <tile id="3">
  <image source="../../graphics/objects/spike_ball.png" width="64" height="64"/>
 </tile>
 <tile id="4">
  <image source="../../graphics/objects/archer.png" width="58" height="56"/>
 </tile>
 <tile id="5">
  <image source="../../graphics/objects/knight.png" width="48" height="46"/>
 </tile>
</tileset>
