import pygame
from os.path import join

pygame.init()


def debug(info, y = 10, x = 10, size = 50, alpha = False):
    font = pygame.font.Font(join("graphics", "ui", "VT323-Regular.ttf"), size)
    display_surface = pygame.display.get_surface()
    debug_surf = font.render(str(info), True, "White")

    new_width = debug_surf.get_width() * 1.5
    new_height = debug_surf.get_height()

    debug_surf = pygame.transform.scale(debug_surf, (new_width, new_height))
    if alpha:
        debug_surf.set_alpha(150)

    debug_rect = debug_surf.get_rect(topleft = (x, y))
    display_surface.blit(debug_surf, debug_rect)