from settings import *
from sprites import Sprite, Cloud
from random import choice, randint
from timer import Timer

class AllSprites(pygame.sprite.Group):
    def __init__(self, width, height, bg_tile = None, top_limit = 0, clouds = {}, horizon_line = 0):
        super().__init__()
        self.display_surface = pygame.display.get_surface()

        #camera offset
        self.offset = vector()

        #border
        self.width = width * TILE_SIZE
        self.height = height * TILE_SIZE
        self.borders = {
            "left" : 0,
            "right" : -self.width + WINDOW_WIDTH,
            "bottom" : -self.height + WINDOW_HEIGHT + 32,
            "top" : top_limit
        }

        #sky
        self.sky = not bg_tile
        self.horizon_line = horizon_line

        #background tile
        if bg_tile: #this background 64x64 but tileset 32x32 we should convert to 64 by multiply
            for col in range(width):
                for row in range( -int(top_limit / TILE_SIZE) - 1 ,height):
                    x = col * TILE_SIZE
                    y = row * TILE_SIZE
                    Sprite((x,y), bg_tile, self, -1)
        else:
            self.large_cloud = clouds["large"]
            self.small_cloud = clouds["small"]

            #large cloud
            self.cloud_direction = -1
            self.large_cloud_speed = 50
            self.large_cloud_x = 0
            self.large_cloud_tiles = int(self.width / self.large_cloud.get_width()) + 2
            self.large_cloud_width ,self.large_cloud_height = self.large_cloud.get_size()

            #small cloud
            self.cloud_timer= Timer(2500, self.create_cloud, True)
            self.cloud_timer.activate()
            for cloud in range(10):
                pos = (randint(0, self.width), randint(self.borders["top"], self.horizon_line))
                surf = choice(self.small_cloud) #random small cloud
                Cloud(pos, surf, self)

        #zoom
        self.zoom_scale = 1
        self.internal_surf_size = (2000,2000)
        self.internal_surf = pygame.Surface(self.internal_surf_size, pygame.SRCALPHA)
        self.internal_rect = self.internal_surf.get_rect(center = (WINDOW_WIDTH / 2 , WINDOW_HEIGHT / 2))
        self.internal_surf_rect_vector = pygame.math.Vector2(self.internal_surf_size)
        self.internal_offset = pygame.math.Vector2()
        self.internal_offset.x = self.internal_surf_size[0] / 2 - WINDOW_WIDTH / 2 #for make internal_surf have origin point like display_surface
        self.internal_offset.y = self.internal_surf_size[1] / 2 - WINDOW_HEIGHT / 2 #for make internal_surf have origin point like display_surface

    def camera_constraint(self): #lock camera
        self.offset.x = self.offset.x if self.offset.x < self.borders["left"] else self.borders["left"]
        self.offset.x = self.offset.x if self.offset.x > self.borders["right"] else self.borders["right"]
        self.offset.y = self.offset.y if self.offset.y > self.borders["bottom"] else self.borders["bottom"]
        self.offset.y = self.offset.y if self.offset.y < self.borders["top"] else self.borders["top"]
    
    def draw_sky(self): #draw sky background if bg tile is empty

        #sky color
        self.internal_surf.fill("#ddc6a1")

        #sea color
        horizon_pos = self.horizon_line + self.internal_offset.y + self.offset.y 
        sea_rect = pygame.FRect(0 , horizon_pos , self.internal_surf_size[1], horizon_pos)
        pygame.draw.rect(self.internal_surf, "#92a9ce", sea_rect)
            #sea light color
        pygame.draw.line(self.internal_surf, "#f5f1de", (0 , horizon_pos), (self.internal_surf_size[1], horizon_pos), 4)

    def draw_large_cloud(self, dt):
        self.large_cloud_x += self.cloud_direction * self.large_cloud_speed * dt

        if self.large_cloud_x <= -self.large_cloud_width: #infinity large cloud
            self.large_cloud_x = 0
        for cloud in range(self.large_cloud_tiles):
            left = self.large_cloud_x + self.large_cloud_width * cloud + self.offset.x
            top = self.horizon_line - self.large_cloud_height + self.internal_offset.y + self.offset.y 
            self.internal_surf.blit(self.large_cloud, (left,top))

    def create_cloud(self):
        pos = (randint(self.width + 500, self.width + 600), randint(self.borders["top"], self.horizon_line))
        surf = choice(self.small_cloud) #random small cloud
        Cloud(pos, surf, self)

    def draw(self, target_pos, dt):
        self.zoom_keyboard_control()

        #offset
        self.offset.x = (-(target_pos[0] - WINDOW_WIDTH / 2)) #set player to center of camera negative for invert
        self.offset.y = (-(target_pos[1] - WINDOW_HEIGHT / 2))
        self.camera_constraint()

        for sprite in sorted(self, key = lambda sprite: sprite.z):
            offset_pos = sprite.rect.topleft + self.offset + self.internal_offset #+ self.offset for change postion of sprite to make camera and + self.internaL_offset for make internal surf have origin point like display_surface
            self.internal_surf.blit(sprite.image, offset_pos)

        scaled_surf = pygame.transform.scale(self.internal_surf, self.internal_surf_rect_vector * self.zoom_scale) #change scale of cameara
        scaled_rect = scaled_surf.get_rect(center = (WINDOW_WIDTH / 2 , WINDOW_HEIGHT / 2))

        if self.sky == True:
            self.cloud_timer.update()
            self.draw_sky()
            self.draw_large_cloud(dt)

        self.display_surface.blit(scaled_surf, scaled_rect)
        
    def zoom_keyboard_control(self):
        keys = pygame.key.get_just_pressed()
        if keys[pygame.K_i]:
            self.zoom_scale += 0.1
        if keys[pygame.K_o]:
            if self.zoom_scale > 1:
                self.zoom_scale -= 0.1

class WorldSprites(pygame.sprite.Group):
    def __init__(self, data):
        super().__init__()
        self.display_surface = pygame.display.get_surface()
        self.data = data
        self.offset = vector()

    def draw(self, target_pos):
        self.offset.x = -(target_pos[0] - WINDOW_WIDTH / 2)
        self.offset.y = -(target_pos[1] - WINDOW_HEIGHT / 2)

        for sprite in sorted(self, key = lambda sprite : sprite.z):
            if sprite.z < Z_LAYER["main"]:
                if sprite.z == Z_LAYER["path"]:
                    if sprite.level <= self.data.unlocked_level:
                        self.display_surface.blit(sprite.image, sprite.rect.topleft + self.offset)
                else:
                    self.display_surface.blit(sprite.image, sprite.rect.topleft + self.offset)
        
        for sprite in sorted(self, key = lambda sprite : sprite.rect.centery):
            if sprite.z == Z_LAYER["main"]:
                if hasattr(sprite, "icon"):
                    self.display_surface.blit(sprite.image, sprite.rect.topleft + self.offset + vector(0, -28)) #make player up a little bit
                else:
                    self.display_surface.blit(sprite.image, sprite.rect.topleft + self.offset)
        
        for sprite in sorted(self, key = lambda sprite : sprite.rect.centery):
            if sprite.z > Z_LAYER["main"]:
                self.display_surface.blit(sprite.image, sprite.rect.topleft + self.offset)

class TextSprites(pygame.sprite.Group):
    def __init__(self):
        super().__init__()
        self.display_surface = pygame.display.get_surface()

    def draw(self):
        for sprite in self:
            self.display_surface.blit(sprite.image, sprite.rect.topleft)