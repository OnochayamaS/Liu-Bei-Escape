from settings import *
from level import Level
from pytmx.util_pygame import load_pygame #for load .tmx files      
from os.path import join #for another operating systemd
from support import *
from data import Data
from debug import debug
from ui import UI
from overworld import Overworld
from startscreen import StartScreen
from endscreen import EndScreen
from fade import fade

class Game:
    def __init__(self):
        pygame.init()
        self.display_surface = pygame.display.set_mode((WINDOW_WIDTH,WINDOW_HEIGHT))
        pygame.display.set_caption("Liu Bei Escape")
        self.clock = pygame.time.Clock()
        self.import_assets() #use func import_assets

        self.ui = UI(self.font, self.ui_frames)
        self.data = Data(self.ui)
        self.startscreen = StartScreen(self.startscreen_frames, self.switch_stage)

        self.tmx_maps = {0: load_pygame(join("data", "levels", "0.tmx")),
                         1: load_pygame(join("data", "levels", "1.tmx")),
                         2: load_pygame(join("data", "levels", "2.tmx")),
                         3: load_pygame(join("data", "levels", "3.tmx")),
                         4: load_pygame(join("data", "levels", "4.tmx")),
                         5: load_pygame(join("data", "levels", "5.tmx")),}
        
        self.tmx_overworld = load_pygame(join("data", "overworld", "overworld.tmx"))
        
        #audio
        self.start_music, self.level_music, self.end_music = False, False, False

        self.target = None
        self.switch_stage("startscreen")

    def switch_stage(self, target, unlock = 0):
        self.target = target

        if self.target == "startscreen":
            #audio
            if not self.start_music:
                self.start_background_music.play(-1)
                self.start_music = True

            #switch stage
            self.current_stage = self.startscreen

        elif self.target == "level":
            #audio
            if not self.level_music:
                self.level_background_music.play(-1)
                self.level_music = True
            if self.start_music:
                self.start_background_music.stop()
                self.start_music = False
            self.dead_sound = False

            #switch stage
            self.current_stage = Level(self.tmx_maps[self.data.current_level], self.level_frames, self.audio_files  , self.data, self.switch_stage)

        elif self.target == "endscreen":
            #audio
            self.end_background_music.play()
            if self.level_music:
                self.level_background_music.stop()
                self.level_music = False

            #switch stage
            self.current_stage = EndScreen(self.data, self.switch_stage, self.endscreen_frames)

        elif self.target == "overworld":
            if unlock > 0:
                self.data.unlocked_level = unlock
            else:
                self.data.health -= 1
            self.current_stage = Overworld(self.tmx_overworld, self.data, self.overworld_frames, self.switch_stage)

    def import_assets(self):
        self.level_frames = {
            "flag": import_folder("graphics", "level", "flag"),
            "floor_spike" : import_folder("graphics", "enemies", "floor_spikes"),
            "player" : import_sub_folders("graphics", "player"),
            "saw" : import_folder("graphics", "enemies", "saw", "animation"),
            "saw_chain" : import_image("graphics", "enemies", "saw", "saw_chain"),
            "moving_platform" : import_folder("graphics", "level", "moving_platform"),
            "spike" : import_image("graphics", "enemies", "spike_ball", "Spiked Ball"),
            "spike_chain" : import_image("graphics", "enemies", "spike_ball", "spiked_chain"),
            "knight" : import_folder("graphics", "enemies", "knight", "run"),
            "archer" : import_sub_folders("graphics", "enemies", "archer"),   
            "arrow" : import_image("graphics", "enemies", "bullets", "arrow"),
            "items" : import_sub_folders("graphics", "items"),
            "particle" : import_folder("graphics", "effects", "particle"),
            "water_top" : import_folder("graphics", "level", "water", "top"),
            "water_body" : import_image("graphics", "level", "water", "body"),
            "bg_tiles" : import_folder_dict("graphics", "level", "bg", "tiles"),
            "large_cloud" : import_image("graphics", "level", "clouds", "large_cloud"),
            "small_cloud" : import_folder("graphics", "level", "clouds", "small"),
            "sign" : import_folder("graphics", "ui", "sign"),
            "willows" : import_folder("graphics", "objects", "willows"),
            "box" : import_folder("graphics", "objects", "box"),
            "bushes" : import_folder("graphics", "objects", "bushes"),
            "pointer" : import_folder("graphics", "objects", "pointer"),
            "ridges" : import_folder("graphics", "objects", "ridges"),
            "stones" : import_folder("graphics", "objects", "stones"),
            "trees" : import_folder("graphics", "objects", "trees"),
            "grass" : import_folder("graphics", "objects", "grass"),
            "boat": import_folder("graphics", "objects", "boat"),
            "guide_text": import_image("graphics", "ui", "guide_text", "guide_text"),
            "press_enter": import_folder("graphics", "ui", "guide_text", "press_enter"),
        }
        
        self.ui_frames = {
            "heart" : import_folder("graphics", "ui", "heart"),
            "coin" : import_image("graphics", "ui", "coin"),
            "key" : import_image("graphics", "ui", "key")
        }

        self.overworld_frames = {
            "water" : import_folder("graphics", "overworld", "water"),
            "path" : import_folder_dict("graphics", "overworld", "path"),
            "icon" : import_sub_folders("graphics", "overworld", "icon"),
            "path" : import_folder_dict("graphics", "overworld", "path"),
            "overworld_sign" : import_folder("graphics", "level", "overworld_sign")
        }

        self.font = pygame.font.Font(join("graphics", "ui", "runescape_uf.ttf"), 40) 

        self.audio_files = {
            "coin" : pygame.mixer.Sound(join("audio", "coin.wav")),
            "attack" : pygame.mixer.Sound(join("audio", "attack.wav")),
            "damage" : pygame.mixer.Sound(join("audio", "damage.wav")),
            "hit" : pygame.mixer.Sound(join("audio", "hit.wav")),
            "jump" : pygame.mixer.Sound(join("audio", "jump.wav")),
            "pearl" : pygame.mixer.Sound(join("audio", "pearl.wav")),
        }

        self.startscreen_frames = {
            "player" : import_folder(join("graphics", "startscreen", "player")),
            "archer" : import_folder(join("graphics", "startscreen", "archer")),
            "background" : import_image(join("graphics", "startscreen", "background"))
        }

        self.endscreen_frames = {
            "background" : import_image(join("graphics", "endscreen", "background")),
            "heart" : import_folder("graphics", "endscreen", "heart")
        }

        #audio
        self.start_background_music = pygame.mixer.Sound(join("audio", "8bitwin.mp3"))
        self.start_background_music.set_volume(0.8)
        self.level_background_music = pygame.mixer.Sound(join("audio", "starlight_city.mp3"))
        self.level_background_music.set_volume(0.5)
        self.end_background_music = pygame.mixer.Sound(join("audio", "endsound.mp3"))
        self.end_background_music.set_volume(0.8)
        self.dead_soundeffects = pygame.mixer.Sound(join("audio", "deadsound.mp3"))
        self.dead_soundeffects.set_volume(0.5)
        self.dead_sound = False
        self.text_sound = pygame.mixer.Sound(join("audio", "text.mp3"))
        
        #timer
        self.start_time = 0
        self.current_time = pygame.time.get_ticks()
        self.second, self.minute, self.hour = 0, 0, 0

    def timer(self):
        self.current_time = pygame.time.get_ticks()
        self.second = int((self.current_time - self.start_time) / 1000)
        if self.second == 60:
            self.start_time = pygame.time.get_ticks()
            self.second = 0
            self.minute += 1
        if self.minute == 60:
            self.minute = 0
            self.hour += 1
        
        time = f'{self.hour:02}:{self.minute:02}:{self.second:02}'
        return time

    def check_dead_sound(self):
        if self.target == "level" and self.data.health <= 0:
            self.level_background_music.stop()
            if not self.dead_sound:
                self.dead_soundeffects.play()
            self.dead_sound = True
            self.level_music = False

    def run(self):
        while True: 
            dt = self.clock.tick() / 1000 #for static speed movement
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_RETURN:
                        if self.data.current_level == 0 and self.data.show_text:
                            self.text_sound.play()
                            self.data.line += 1
            
            #timer
            if self.startscreen.firsttick:
                self.start_time = pygame.time.get_ticks()
                self.startscreen.firsttick = False
            if not self.startscreen.firsttick:
                self.timer()
            if self.target == "endscreen":
                pass
            else:
                self.data.time = self.timer()
                self.data.second = int((self.current_time - self.start_time) / 1000)

            self.current_stage.run(dt) # func run from level.py use dt for static speed movement every fps
            self.check_dead_sound()

            if self.target == "level":
                self.ui.update(dt)
                #show time
                debug(f'{self.hour:02}:{self.minute:02}:{self.second:02}', 25, WINDOW_WIDTH /2.5)

            pygame.display.update()

if __name__ == "__main__":
    game = Game()
    game.run()
