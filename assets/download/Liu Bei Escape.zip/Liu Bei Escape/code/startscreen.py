from settings import *
from timer import Timer
from debug import debug
from fade import fade

class StartScreen:
    def __init__(self, frames, switch_stage = None):
        self.display_surface = pygame.display.get_surface()
        self.switch_stage = switch_stage

        #text
        self.show_text = True

        #background
        self.background = frames["background"]

        #animate
        self.frames_index = 0
        self.animation_speed = ANIMATION_SPEED
        
        self.player = frames["player"]
        self.archer = frames["archer"]

        #timer
        self.text_timer = Timer(800, func = self.toggle_text, repeat = True, autostart = True)

        self.firsttick = False
    
    def toggle_text(self):
        self.show_text = not self.show_text

    def setup(self):
        if self.show_text == True:
            debug("Press SPACE To Start", WINDOW_HEIGHT / 1.5, WINDOW_WIDTH / 4 + 25, alpha = True)


    def input(self):
        keys = pygame.key.get_pressed()

        if keys[pygame.K_SPACE]:
            self.firsttick = True
            fade(func = lambda: self.switch_stage("level"))

    def animate(self, dt):
        self.frames_index += self.animation_speed * dt
        #player
        self.player_image = self.player[int(self.frames_index % len(self.player))]
        #archer
        self.archer_image = self.archer[int(self.frames_index % len(self.archer))]
        self.archer_image = pygame.transform.flip(self.archer_image, True, False)
        


    def run(self, dt):
        self.animate(dt)

        #blit
        self.display_surface.blit(self.background, (0,0))
        self.display_surface.blit(self.player_image, (325, 90))
        self.display_surface.blit(self.archer_image, (805, 110))

        self.input()
        self.setup()
        self.text_timer.update()
        


