from settings import *
from sprites import Sprite, MovingSprite, AnimatedSprite, Spike, Item, ParticleEffectSprite, Sign, Guidetext
from player import Player
from groups import AllSprites, TextSprites
from enemies import Knight, Archer, Arrow
from debug import debug
from fade import fade
from os.path import join

class Level:
    def __init__(self, tmx_map, level_frames, audio_files, data, switch_stage):
        self.display_surface = pygame.display.get_surface()
        
        #level data
        self.level_width = tmx_map.width * TILE_SIZE
        self.level_bottom = tmx_map.height * TILE_SIZE
        tmx_level_properties = tmx_map.get_layer_by_name("Data")[0].properties
        self.level_unlock = tmx_level_properties["level_unlock"]
        if tmx_level_properties["bg"]:
            bg_tile = level_frames["bg_tiles"][tmx_level_properties["bg"]]
        else:
            bg_tile = None

        #groups
        self.all_sprites = AllSprites(tmx_map.width, tmx_map.height, bg_tile, tmx_level_properties["top_limit"], clouds= {"large" : level_frames["large_cloud"], "small" : level_frames["small_cloud"]}, horizon_line = tmx_level_properties["horizon_line"]) #Sprite Group in AllSprites class
        self.guide_text_sprites = TextSprites()
        self.collision_sprites = pygame.sprite.Group() #Collision Group
        self.semi_collision_sprites = pygame.sprite.Group() #semi-coliision ex. platforms
        self.damage_sprites = pygame.sprite.Group()
        self.item_sprites = pygame.sprite.Group()
        self.sign_sprites = pygame.sprite.Group()

        #enemies groups
        self.knight_sprites = pygame.sprite.Group()
        self.arrow_sprites = pygame.sprite.Group()

        #frames
        self.arrow_surf  = level_frames["arrow"]
        self.particle_frames = level_frames["particle"]
        self.sign_frames = level_frames["sign"]

        #data
        self.data = data

        self.switch_stage = switch_stage

        #audio
        self.coin_sound = audio_files["coin"]
        self.coin_sound.set_volume(0.06)
        self.arrow_sound = audio_files["pearl"]
        self.arrow_sound.set_volume(1)
        self.hit_sound = audio_files["hit"]
        self.hit_sound.set_volume(0.07)

        self.player_startpos = (0,0)

        #sign
        self.sign_created = False

        #guidetext
        if self.data.current_level == 0 and self.data.start_game:
            self.guide_text = True
        else:
            self.guide_text = False
        self.guide_text_frames = level_frames["guide_text"]
        self.press_enter = level_frames["press_enter"]
        self.document = self.load_textdocument(join("graphics", "ui", "guide_text", "guidetext.txt"))

        #setup
        self.setup(tmx_map, level_frames, audio_files) #use func setup
        self.generate_guidetext()

    def setup(self, tmx_map, level_frames, audio_files):


        #decoration
        for obj in tmx_map.get_layer_by_name("Decoration"):
            objects = obj.name[:-1]
            frames = level_frames[objects][int(obj.name[-1])]
            if objects in obj.name:
                    Sprite((obj.x, obj.y), frames, self.all_sprites, Z_LAYER["background"])
        #objects
        for obj in tmx_map.get_layer_by_name("Objects"):
            if obj.name == "player":
                self.player_startpos = (obj.x, obj.y)
                self.player = Player((obj.x , obj.y - 384 if self.data.current_level == 0 and not self.data.show_text else obj.y), self.all_sprites, self.collision_sprites, self.semi_collision_sprites, level_frames["player"], self.data, audio_files["attack"], audio_files["jump"], audio_files["damage"]) #Use Player class
            else:
                frames = level_frames[obj.name]

                if obj.name == "floor_spike":
                    AnimatedSprite((obj.x, obj.y), frames, (self.all_sprites, self.damage_sprites), flip = obj.properties["flip"])
                else:
                    AnimatedSprite((obj.x, obj.y), frames, self.all_sprites)

            if obj.name == "flag":
                self.flag_pos = (obj.x, obj.y)
                self.flag_size = (obj.width, obj.height)
                self.level_finish_rect = pygame.FRect((obj.x, obj.y) ,(obj.width, obj.height))

        #tiles
        for layer in ["WaterBG", "Platforms", "Terrain", "FG", "BG"]:
            for x, y, surf in tmx_map.get_layer_by_name(layer).tiles():
                groups = [self.all_sprites]
                if layer == "Terrain" : groups.append(self.collision_sprites)
                if layer == "Platforms" : groups.append(self.semi_collision_sprites)

                match layer:
                    case "BG" : z = Z_LAYER["background"]
                    case "WaterBG" : z = Z_LAYER["water_floor"]
                    case "FG" : z = Z_LAYER["grass"]
                    case _ : z = Z_LAYER["main"]

                Sprite((x * TILE_SIZE, y * TILE_SIZE), surf, groups, z) #Use Sprite class (pos, surface, groups)

        #moving objects
        for obj in tmx_map.get_layer_by_name("Moving Objects"):
            if obj.name == "spike":
                Spike(
                    pos = (obj.x + obj.width / 2, obj.y + obj.height / 2), #set postion to center
                    surf = level_frames["spike"],
                    radius = obj.properties["radius"],
                    speed = obj.properties["speed"],
                    start_angle = obj.properties["start_angle"],
                    end_angle = obj.properties["end_angle"],
                    groups = (self.all_sprites, self.damage_sprites)
                )

                for radius in range(0, obj.properties["radius"], 20): #draw spike_chain every 20
                    Spike(
                        pos = (obj.x + obj.width / 2, obj.y + obj.height / 2), #set postion to center
                        surf = level_frames["spike_chain"],
                        radius = radius, #radius form for loop
                        speed = obj.properties["speed"],
                        start_angle = obj.properties["start_angle"],
                        end_angle = obj.properties["end_angle"],
                        groups = self.all_sprites,
                        z = Z_LAYER["background"]
                    )

            else:
                frames = level_frames[obj.name]
                groups = (self.all_sprites, self.semi_collision_sprites) if obj.properties["platform"] else (self.all_sprites, self.damage_sprites) 
                if obj.width > obj.height:
                    move_dir = "x"
                    start_pos = (obj.x, obj.y + obj.height / 2)
                    end_pos =  (obj.x + obj.width, obj.y + obj.height / 2)
                else:
                    move_dir = "y"
                    start_pos = (obj.x + obj.width / 2, obj.y)
                    end_pos = (obj.x + obj.width / 2, obj.y + obj.height)
                speed = obj.properties["speed"] #get speed from platfrom properties
                MovingSprite(groups, start_pos, end_pos, move_dir, speed ,frames , obj.properties['flip'])
                
                if obj.name == "saw":
                    #chain of saw
                    #horizontal
                    if move_dir == "x":
                        y = start_pos[1] - level_frames["saw_chain"].get_height() / 2 # - level_frames height for make saw center = chain saw
                        left = int(start_pos[0])
                        right = int(end_pos[0])
                        for x in range(left, right, 20): #loop for draw sprite class every 20
                            Sprite((x, y), level_frames["saw_chain"], self.all_sprites, Z_LAYER["background"]) #chain of saw
                    #vertical
                    else:
                        x = start_pos[0] - level_frames["saw_chain"].get_width() / 2
                        top = int(start_pos[1])
                        bottom = int(end_pos[1])
                        for y in range(top, bottom, 20):
                            Sprite((x, y), level_frames["saw_chain"], self.all_sprites, Z_LAYER["background"]) #chain of saw

        #enemies
        for obj in tmx_map.get_layer_by_name("Enemies"):
            if obj.name == "knight":
                Knight((obj.x , obj.y), level_frames["knight"], (self.all_sprites, self.damage_sprites, self.knight_sprites), self.collision_sprites)
            if obj.name == "archer":
                Archer(
                    pos = (obj.x, obj.y), 
                    frames = level_frames["archer"], 
                    groups = self.all_sprites, 
                    reverse = obj.properties["reverse"], 
                    player = self.player, 
                    create_arrow = self.create_arrow)
        
        #items
        for obj in tmx_map.get_layer_by_name("Items"):
            Item(obj.name, (obj.x, obj.y), level_frames["items"][obj.name], (self.all_sprites, self.item_sprites), self.data)

        #water
        for obj in tmx_map.get_layer_by_name("Water"):
            rows = int(obj.height / TILE_SIZE)
            cols = int(obj.width / TILE_SIZE)
            for row in range(rows):
                for col in range(cols):
                    x = obj.x + col * TILE_SIZE
                    y = obj.y + row * TILE_SIZE
                    if row == 0:
                        AnimatedSprite((x,y), level_frames["water_top"], self.all_sprites, z = Z_LAYER["water"])
                    else:
                        Sprite((x,y) ,level_frames["water_body"] , self.all_sprites, Z_LAYER["water"])

    def create_arrow(self, pos, direction):
        Arrow(pos, (self.all_sprites, self.damage_sprites, self.arrow_sprites), self.arrow_surf, direction, 150)
        self.arrow_sound.play()

    #particle & collision
    def arrow_collision(self): #if pearl collision with tiles
        for sprite in self.collision_sprites:
            sprite = pygame.sprite.spritecollide(sprite, self.arrow_sprites, True)
            if sprite:
                ParticleEffectSprite((sprite[0].rect.center), self.particle_frames, self.all_sprites)

    def hit_collision(self): #if pearl collision with player
        for sprite in self.damage_sprites:
            if sprite.rect.colliderect(self.player.hitbox_rect):
                self.player.get_damage()
                if hasattr(sprite, "arrow"): # if that sprie has attribute "pearl" remove sprite
                    sprite.kill()
                    ParticleEffectSprite((sprite.rect.center), self.particle_frames , self.all_sprites)

    def item_collision(self): #if player collision with items
        if self.item_sprites:
                for sprite in self.item_sprites:
                    if self.player.hitbox_rect.colliderect(sprite.rect):
                        sprite.kill()
                        sprite.activate() # +coins and check type of items
                        ParticleEffectSprite((sprite.rect.center), self.particle_frames , self.all_sprites)
                        self.coin_sound.play()

    def attack_collision(self):
        for target in self.arrow_sprites.sprites() + self.knight_sprites.sprites():
            facing_target = self.player.rect.centerx < target.rect.centerx and self.player.facing_right or \
                            self.player.rect.centerx > target.rect.centerx and not self.player.facing_right
            if target.rect.colliderect(self.player.rect) and self.player.attacking and facing_target:
                target.reverse()
                self.hit_sound.play()

    def check_constraint(self):
        #left - right
        if self.player.hitbox_rect.left <= 0:
            self.player.hitbox_rect.left = 0
        if self.player.hitbox_rect.right >= self.level_width:
            self.player.hitbox_rect.right = self.level_width

        #bottom
        if self.player.hitbox_rect.bottom > self.level_bottom:
            self.player.hitbox_rect.topleft = self.player_startpos
            self.data.health -= 1
        
        if self.player.hitbox_rect.colliderect(self.level_finish_rect) and self.data.key >= 2:
            #sign press F to next stage
            if not self.sign_created:
                Sign((self.flag_pos[0] + self.flag_size[0] / 2, self.flag_pos[1]), self.sign_frames, (self.all_sprites, self.sign_sprites))
                self.sign_created = True
            keys = pygame.key.get_pressed()
            if keys[pygame.K_f]:
                self.switch_stage("overworld", self.level_unlock)
                self.data.key = 0

        for sprite in self.sign_sprites:
            #kill sign if sign away from flag
            if not self.player.hitbox_rect.colliderect(self.level_finish_rect):
                self.sign_created = False
                sprite.kill()
        
        if not self.player.alive:
            debug("Press ENTER To Respawn", WINDOW_HEIGHT / 1.5, WINDOW_WIDTH / 4 + 15)
            keys = pygame.key.get_pressed()
            if keys[pygame.K_RETURN]:
                self.data.coins, self.data.key, self.data.health = 0, 0, 5
                self.data.unlocked_level,self.data.current_level = 0, 0
                self.player.alive = True
                fade(func = lambda: self.switch_stage("level"))

    def generate_guidetext(self):
        if self.guide_text:
            self.text = Guidetext((WINDOW_WIDTH / 2, WINDOW_HEIGHT - 150), self.guide_text_frames, self.guide_text_sprites)
            self.data.start_game = False

            AnimatedSprite((self.text.rect.x + 1045, self.text.rect.y + 125), self.press_enter, self.guide_text_sprites)

    def check_generate_guide_text(self):
        if self.data.show_text and self.guide_text:
            if self.data.line < len(self.document):
                font = pygame.font.Font(join("graphics", "ui", "VT323-Regular.ttf"), 28)
                text = font.render(self.document[self.data.line], True, "#535353")
                self.display_surface.blit(text, (self.text.rect.x + 45, self.text.rect.y + 40))

            if self.data.line > len(self.document) - 1:
                self.data.show_text = False
                for sprite in self.guide_text_sprites:
                    sprite.kill()
        
    def overlay(self):
        if self.data.show_text:
            overlay = pygame.Surface(self.display_surface.get_size())
            overlay.set_alpha(128)
            overlay.fill((0, 0, 0))
            self.display_surface.blit(overlay, (0,0))

    def load_textdocument(self, filename):
        with open(filename, "r", encoding="utf-8") as file:
            lines = file.readlines()
        return lines

    def run(self, dt):  
        self.display_surface.fill("#ddc6a1")
        self.all_sprites.draw(self.player.hitbox_rect.center, dt) #Draw all sprite from self.all_sprites Group
        self.all_sprites.update(dt) #func update from player.py to input key and move sprite and use func update from sprites.py
        self.arrow_collision()
        self.hit_collision()
        self.item_collision()
        self.attack_collision()
        self.check_constraint()

        #guidetext
        self.overlay()
        self.guide_text_sprites.draw()
        self.guide_text_sprites.update(dt)
        self.check_generate_guide_text()