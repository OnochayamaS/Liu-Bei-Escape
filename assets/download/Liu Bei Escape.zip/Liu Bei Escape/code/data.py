class Data:
    def __init__(self, ui):
        self.ui = ui
        self._coins = 0
        self._key = 0
        self._health = 5
        self.ui.create_hearts(self._health) #set starter hearts

        self.unlocked_level = 0
        self.current_level = 0

        self.time = 0
        self.second = 0

        self.start_game = True
        self.show_text = True
        self.line = 0
    
    @property #getter
    def health(self): 
        return self._health
    
    @health.setter #setter
    def health(self, value): #from player.py when self.data.healt -= 1 setter value -= 1
        self._health = value
        self.ui.create_hearts(value)

    @property #getter
    def coins(self):
        return self._coins
    
    @coins.setter #setter
    def coins(self, value):
        self._coins = value #from sprites.py when self.data.coins += 1 setter value += 1
        self.ui.show_coins(self.coins)

    @property #getter
    def key(self):
        return self._key
    
    @key.setter #setter
    def key(self, value):
        self._key = value #from sprites.py when self.data.coins += 1 setter value += 1
        self.ui.show_key(self.key)