from settings import *
from timer import Timer
from os.path import join #for another operating system
from math import sin


class Player(pygame.sprite.Sprite):
    def __init__(self, pos, groups, collision_sprites, semi_collision_sprites, frames, data, attack_sound, jump_sound, damage_sound):
        super().__init__(groups)
        self.z = Z_LAYER["main"]

        #image and animate
        self.frames = frames
        self.frame_index = 0
        self.state = "idle"
        self.facing_right = True
        self.image = self.frames[self.state][self.frame_index]
        # self.image = pygame.Surface((38.32,25)) #player surface
        # self.image.fill("blue")

        #rect
        self.rect = self.image.get_frect(topleft = pos) #frect for float ex. x = 12.11 y = 2.33
        self.hitbox_rect = self.rect.inflate(-76 , -36) #inflate use for remove space of image
        self.old_rect = self.hitbox_rect.copy()
        
        #movement
        self.direction = vector()
        self.speed = 200
        self.gravity = 1200
        self.jump = False
        self.jump_height = 700
        self.attacking = False

        #collision
        self.collision_sprites = collision_sprites
        self.on_surface = {"floor" : False, "left" : False, "right" : False}
        self.platform = None
        self.semi_collision_sprites = semi_collision_sprites
        
        #timer
        self.timers = { #use timer for can't not control direction after wall jump and remove problem can't not wall jump
            "wall jump" : Timer(500),
            "wall slide block" : Timer(1000),
            "platform skip" : Timer(100),
            "attack block" : Timer(500),
            "hit" : Timer(1000),
        }

        #data
        self.data = data

        #audio
        self.attack_sound = attack_sound
        self.attack_sound.set_volume(0.2)
        self.jump_sound = jump_sound
        self.jump_sound.set_volume(0.07)
        self.damage_sound = damage_sound
        self.damage_sound.set_volume(0.4)

        #status
        self.alive = True

    def input(self):
        keys = pygame.key.get_pressed()
        input_vector = vector(0,0)

        if self.alive and not self.data.show_text:
            if not self.timers["wall jump"].active: #if timer is not active can't now control while wall jump
                if keys[pygame.K_a]:
                    input_vector.x -= 1
                    self.facing_right = False
                if keys[pygame.K_d]:
                    input_vector.x += 1
                    self.facing_right = True

                if keys[pygame.K_s]:
                    self.timers["platform skip"].activate()

                if keys[pygame.K_f]:
                    self.attack()

                self.direction.x = input_vector.normalize().x if input_vector else input_vector.x
            if keys[pygame.K_w]:
                self.jump = True


    def move(self,dt):
        if self.alive and not self.data.show_text:
            #horizontal
            self.hitbox_rect.x += self.direction.x * self.speed * dt # multiply with dt because for static movement every fps
            self.collision("horizontal")

            #vertical
            #walls slide
        
            if not self.on_surface["floor"] and any((self.on_surface["left"], self.on_surface["right"])) and not self.timers["wall slide block"].active: #if not on floor but on left or right and wall slide block timer = false when wall slide block timer = true player can't wall slide
                self.direction.y = 0
                self.hitbox_rect.y += self.gravity / 10 * dt

            else: #falling
                self.direction.y += self.gravity / 2 * dt
                self.hitbox_rect.y += self.direction.y * dt
                self.direction.y += self.gravity / 2 *dt
            
            if self.jump == True:
                if self.on_surface["floor"] == True:
                    self.direction.y = -self.jump_height
                    self.timers["wall slide block"].activate() #func activate from timer.py
                    self.hitbox_rect.bottom -= 1 #use for fix can't jump on vertical platform
                    self.jump_sound.play()
                    
                # walls jump
                elif any((self.on_surface["left"], self.on_surface["right"])) and not self.timers["wall slide block"].active:
                    self.timers["wall jump"].activate() #func activate from timer.py
                    self.direction.y = -self.jump_height
                    self.direction.x = 1 if self.on_surface["left"] else -1
                    self.jump_sound.play()

                self.jump = False

            self.collision("vertical")
            self.semi_collision()
            self.rect.center = self.hitbox_rect.center

    def platform_move(self, dt):
        if self.platform:
            self.hitbox_rect.topleft += self.platform.direction * self.platform.speed * dt

    def check_contact(self):
        collide_rect = [sprite.rect for sprite in self.collision_sprites] #get rect of tiles
        semi_collide_rect = [sprite.rect for sprite in self.semi_collision_sprites] #get rect if semi_collision_sprites Group

        #Build rectangle around the player for check collision to wall jumps
        floor_rect = pygame.Rect(self.hitbox_rect.bottomleft,(self.hitbox_rect.width, 2)) #Rect((left, top), (width, height))
        right_rect = pygame.Rect(self.hitbox_rect.topright + vector(0,self.hitbox_rect.height / 4), (2,self.hitbox_rect.height / 2)) # solution of topright + vector is (x,y) + (0,self.height/4) if topright = (300,100) mean (300,100 + self.rect.height / 4) **the more y increase the the output is lower
        left_rect = pygame.Rect(self.hitbox_rect.topleft + vector(-2,self.hitbox_rect.height / 4), (2,self.hitbox_rect.height / 2))

        self.on_surface ["floor"] = True if floor_rect.collidelist(collide_rect) >= 0 or floor_rect.collidelist(semi_collide_rect) >= 0 and self.direction.y >= 0 else False #if floor_rect.collidelist(collide_rect) == -1 mean floating
        self.on_surface ["right"] = True if right_rect.collidelist(collide_rect) >= 0 else False #if floor_rect.collidelist(collide_rect) == -1 mean not collision in right
        self.on_surface ["left"] = True if left_rect.collidelist(collide_rect) >= 0 else False #if floor_rect.collidelist(collide_rect) == -1 mean not collision in left

        #platform
        self.platform = None
        sprites = self.collision_sprites.sprites() + self.semi_collision_sprites.sprites()
        for sprite in [sprite for sprite in sprites if hasattr(sprite, "moving")]:
            if sprite.rect.colliderect(floor_rect):
                self.platform = sprite

    def collision(self, axis):
        for sprite in self.collision_sprites: #loop sprite not player sprite but it is all of tiles because player is not in the collision_sprites it just ascess with this group
            if sprite.rect.colliderect(self.hitbox_rect): #self.rect mean player rect -----> it mean if tiles.rect colliderect player.rect
                if axis == "horizontal":
                    #left
                    if self.hitbox_rect.left <= sprite.rect.right and int(self.old_rect.left) >= int(sprite.old_rect.right): #self.rect.left it is position leftside of rectangle ex. self.rect.left = 110
                        self.hitbox_rect.left = sprite.rect.right

                    #right
                    if self.hitbox_rect.right >= sprite.rect.left and int(self.old_rect.right) <= int(sprite.old_rect.left):
                        self.hitbox_rect.right = sprite.rect.left
                else: # == vertical
                    #top When jumping and hitting the block above
                    if self.hitbox_rect.top <= sprite.rect.bottom and int(self.old_rect.top) >= int(sprite.old_rect.bottom):
                        self.hitbox_rect.top = sprite.rect.bottom
                        if hasattr(sprite, "moving"): #platforms
                            self.hitbox_rect.top += 6 #use for fix player stuck with platforms

                    #bottom
                    if self.hitbox_rect.bottom >= sprite.rect.top and int(self.old_rect.bottom) <= int(sprite.old_rect.top):
                        self.hitbox_rect.bottom = sprite.rect.top
                    self.direction.y = 0

    #for platforms
    def semi_collision(self):
        if not self.timers["platform skip"].active:
            for sprite in self.semi_collision_sprites: #loop sprite form semi_collision group
                if sprite.rect.colliderect(self.hitbox_rect):
                    if self.hitbox_rect.bottom >= sprite.rect.top and int(self.old_rect.bottom) <= sprite.old_rect.top:
                        self.hitbox_rect.bottom = sprite.rect.top
                        if self.direction.y > 0: #for fix jump on platform
                            self.direction.y = 0


    def update_timers(self):
        for timer in self.timers.values():
            timer.update() #use func update() from timer.py to update every timer in self.timers


    def animate(self, dt):
        self.frame_index += ANIMATION_SPEED * dt
        if self.state == "attack" and self.frame_index >= len(self.frames[self.state]): #waiting for attack animation finish
            self.state = "idle"
        self.image = self.frames[self.state][int(self.frame_index % len(self.frames[self.state]))]
        self.image = self.image if self.facing_right else pygame.transform.flip(self.image, True, False) #.flip (surf, v, h)

        if self.attacking == True and self.frame_index > len(self.frames[self.state]):
            self.attacking = False

    def get_state(self):
        if self.on_surface["floor"]:
            if self.attacking == True:
                self.state = "attack"
            else:
                self.state = "idle" if self.direction.x == 0 else "run"
        else:
            if self.attacking == True:
                self.state = "air_attack"
            else:
                if any((self.on_surface["left"], self.on_surface["right"])):
                    self.state = "wall"
                else:
                    self.state = "jump" if self.direction.y < 0 else "fall"

    def attack(self):
        if not self.timers["attack block"].active:
            self.attacking = True
            self.frame_index = 0 #if run the game frames_index will greater than 5 to use attack should be set to 0
            self.attack_sound.play()
            self.timers["attack block"].activate()

    def get_damage(self):
        if not self.timers["hit"].active:
            self.data.health -= 1
            self.damage_sound.play()
            self.timers["hit"].activate()
    
    def flicker(self):
        if self.timers["hit"].active and sin(pygame.time.get_ticks() * 200) >= 0:
            white_mask = pygame.mask.from_surface(self.image) #for ignore space of picture black = 0 white = 1
            white_surf = white_mask.to_surface() #set mask to surface
            white_surf.set_colorkey((0,0,0)) #remove blackcolor
            self.image = white_surf

    def die(self):
        if self.data.health <= 0:
            self.data.health = 0
            self.alive = False

    def update(self, dt): #for use func input , move
        self.old_rect = self.hitbox_rect.copy() #previous frame of self.rect
        self.update_timers()

        self.input()
        self.move(dt)
        self.check_contact()
        self.platform_move(dt)

        self.get_state()
        self.animate(dt)
        self.flicker()
        self.die()