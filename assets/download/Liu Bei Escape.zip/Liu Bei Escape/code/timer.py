from pygame.time import get_ticks

class Timer:
    def __init__(self, duration, func = None, repeat = False, autostart = False):
        self.duration = duration
        self.func = func
        self.start_time = 0
        self.active = False
        self.repeat = repeat
        if autostart:
            self.activate()

    def activate(self):
        self.active = True
        self.start_time = get_ticks() #set start_time ex. run start_time = 0 when activate() after run 2 second self.start_time = 2000

    def deactivate(self):
        self.active = False
        self.start_time = 0 #reset start_time
        if self.repeat == True: #repeat timer
            self.activate()

    def update(self): #active when call func activate()
        if self.active == True:
            current_time = get_ticks() #current time
            if current_time - self.start_time >= self.duration: #ex. self.start_time = 2000 , self.duration = 10000 when current_time = 12000 timer will deactivate()
                if self.func and self.start_time != 0:
                    self.func()
                self.deactivate()