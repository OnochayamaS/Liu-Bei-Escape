from settings import *
from sprites import AnimatedSprite
from random import randint
from timer import Timer

class  UI:
    def __init__(self, font, frames):
        self.display_surface = pygame.display.get_surface()
        self.sprites = pygame.sprite.Group()
        self.font = font

        #health
        self.heart_frames = frames["heart"]
        self.heart_width = self.heart_frames[0].get_width()
        self.heart_padding = 5

        #coins
        self.coin_amount = 0
        self.coin_timer = Timer(2000)
        self.key_timer = Timer(2000)
        self.coin_surf = frames["coin"]
        self.key_surf = frames["key"]

    def create_hearts(self, amount):
        for sprite in self.sprites:
            sprite.kill()
        for heart in range(amount):
            x = 10 + heart * (self.heart_width + self.heart_padding)
            y = 20
            Heart((x,y), self.heart_frames, self.sprites)
    def display_text(self):

        #coins display
        if self.coin_timer.active:
            self.text_surf = self.font.render(str(self.coin_amount), False, "White")
            self.text_rect = self.text_surf.get_frect(topleft = (16, 34))
            self.display_surface.blit(self.text_surf, self.text_rect)

            coin_rect = self.coin_surf.get_frect(center = self.text_rect.bottomleft).move(0,-6)
            self.display_surface.blit(self.coin_surf, coin_rect)
        
        #key display
        if self.key_timer.active:
            self.text_surf = self.font.render(str(self.key_amount), False, "White")
            self.text_rect = self.text_surf.get_frect(topleft = (16, 70))
            self.display_surface.blit(self.text_surf, self.text_rect)

            key_rect = self.key_surf.get_frect(center = self.text_rect.bottomleft).move(0,-6)
            self.display_surface.blit(self.key_surf, key_rect)

    def show_coins(self, amount): #for link with data.py in setter
        self.coin_amount = amount
        self.coin_timer.activate()
    
    def show_key(self, amount):
        self.key_amount = amount
        self.key_timer.activate()
    
    def update(self, dt):
        self.sprites.update(dt)
        self.sprites.draw(self.display_surface)
        self.display_text()
        self.coin_timer.update()
        self.key_timer.update()

class Heart(AnimatedSprite):
    def __init__(self, pos, frames, groups, scale = (16,14)):
        super().__init__(pos, frames, groups, scale)
        self.active = False

    def animate(self, dt):
        self.frames_index += ANIMATION_SPEED * dt
        if self.frames_index < len(self.frames):
            self.image = self.frames[int(self.frames_index)]
        else:
            self.active = False
            self.frames_index = 0 


    def update(self, dt):
        if self.active:
            self.animate(dt)
        else:
            if randint(0 , 2000) == 1:
                self.active = True
        