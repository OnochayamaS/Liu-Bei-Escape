from settings import *

def fade(width = WINDOW_WIDTH, height = WINDOW_HEIGHT, func = None):
    display_surface = pygame.display.get_surface()
    fade = pygame.Surface((width, height))
    fade.fill((0,0,0))
    for alpha in range(0, 300):
        fade.set_alpha(alpha)
        display_surface.fill((255,255,255))
        display_surface.blit(fade, (0,0))
        pygame.display.update()

    fade_status = True
    if fade_status == True:
        func()