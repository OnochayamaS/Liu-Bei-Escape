from settings import *
from debug import debug
from ui import Heart
from timer import Timer
from fade import fade

class EndScreen:
    def __init__(self, data, switch_stage, endscreen_frames):
        self.display_surface = pygame.display.get_surface()
        self.switch_stage = switch_stage
        
        #data
        self.data = data
        self.score = int(self.data.health * self.data.coins / self.data.second * 1000)

        #groups
        self.sprites = pygame.sprite.Group()

        self.background = endscreen_frames["background"]
        self.heart_frames = endscreen_frames["heart"]
        self.heart_width = self.heart_frames[0].get_width()
        self.heart_height = self.heart_frames[0].get_height()
        self.heart_padding = 5

        #timer
        self.show_text = True
        self.text_timer = Timer(800, func = self.toggle_text, repeat = True, autostart = True)

        self.create_heart()

    def setup(self):
        debug(self.data.coins, 220, 545, 120)
        debug(self.data.time, 360, 570, 120)
        debug(self.score, 500, 720, 120)
        if self.show_text == True:
            debug("Press SPACE To Continue", 660, WINDOW_WIDTH / 4 - 20, alpha = True)

    def create_heart(self):
        for heart in range(self.data.health):
            x = 430 + heart * (self.heart_width + self.heart_padding)
            y = 90
            Heart((x,y), self.heart_frames, self.sprites)

    def toggle_text(self):
        self.show_text = not self.show_text

    def input(self):
        keys = pygame.key.get_pressed()
        if keys[pygame.K_SPACE]:
            self.data.coins, self.data.key, self.data.health = 0, 0, 5
            self.data.unlocked_level,self.data.current_level = 0, 0
            
            fade(func = lambda: self.switch_stage("startscreen"))
            
    def run(self, dt):
        self.display_surface.blit(self.background, (0,0))
        self.setup()
        self.sprites.update(dt)
        self.sprites.draw(self.display_surface)
        self.text_timer.update()
        self.input()